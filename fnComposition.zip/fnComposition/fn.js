const sliceBread = bread => `${bread} is sliced`;


const spreadButter = bread => `Butter spread on ${bread}`;


const addFilling = bread => `Filling added to ${bread}`;

const makeSandwich = bread => addFilling(spreadButter(sliceBread(bread)));

console.log(makeSandwich("Whole Wheat")); 